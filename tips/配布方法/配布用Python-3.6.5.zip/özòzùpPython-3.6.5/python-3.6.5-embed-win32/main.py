import PySimpleGUI
from typing_extensions import TypedDict

if __name__ == "__main__":
    class Point2D(TypedDict):
        x: int
        y: int
        label: str

    a: Point2D = {'x': 1, 'y': 2, 'label': 'good'}  # OK
    # b: Point2D = {'z': 3, 'label': 'bad'}           # Fails type check
    print("Hello, world!")
    input("コレが表示されたらOK!")