import PySimpleGUI
import time

if __name__ == "__main__":
    print("Hello, world!")
    print("コレが表示されたらOK!")
    time.sleep(10)
