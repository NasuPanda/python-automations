# Python配布

## 環境

- Puython 3.6.5

## 参考記事

参考

[超軽量、超高速な配布用Python「embeddable python」 - Qiita](https://qiita.com/mm_sys/items/1fd3a50a930dac3db299)

tkinterの導入

[Python embeddable zip: install Tkinter - Stack Overflow](https://stackoverflow.com/questions/37710205/python-embeddable-zip-install-tkinter)


## 導入の流れ

### ダウンロード

https://www.python.org/downloads/release/python-365/

Windows x86-64 embeddable zip file を選択してダウンロード、解凍。
`python-****-embed-win32`以下のファイルはそのままに。

### `pip`

#### `python**.__pth`ファイルの修正

↓のコメントアウトを解除。

```
# before
# import site

# after
import site
```

#### `get-pip.py`

`get-pip.py`をダウンロードするか、ファイルを作成して以下からコピーしてくる。

https://bootstrap.pypa.io/get-pip.py

#### 適当な`hoge.pth`ファイル

`python.exe`と同じフォルダに`.pth`拡張子のファイルを作成(名前は自由)、以下を追記。

```
import sys; sys.path.append('')
```


### `pip install`

コマンドプロンプトで作業する。

```bash
cd python.exeが居るフォルダ

# dirでPython.exeが居るフォルダか確認する
dir
# get-pipをインストール
python get-pip.py
```

#### 使うコマンド

`python -m pip install`を使う。

```bash
# インストール
python -m pip install opencv-python

# インストールの確認
python -m pip list
```

## 実行

`python.exe`と同じ階層に以下のような`main.bat`(もしくは`main.cmd`ファイル)を作成。

```bat:main.bat
rem このファイルの位置を作業ディレクトリに
cd /d %~dp0
rem main.pyを実行
python.exe main.py
```

`bat`を実行すると`main.py`が実行される。

### 配布用の`実行.bat`

ひとつ上の階層に以下のような`実行.bat`があると良いと思われる。

```bat:実行.bat
python-3.6.5-embed-win32/main.cmd
```

## 注意点

### `tkinter`を導入したい場合

1. 組み込みPython(通常のPython)をインストール
   1. https://www.python.org/downloads/release/python-365/ から「embeddable python」 と同じバージョンを選択してインストーラーでインストールすれば良い。
   2. 使用後に消せば環境は汚染されない。はず。
2. https://stackoverflow.com/questions/37710205/python-embeddable-zip-install-tkinter を参考に`tkinter`関係のフォルダ/ファイルをコピーする
   1. tcl folder to embedded_distribution_folder\ (root folder of the embedded distribution)
   2. tkinter folder (which is under Lib) either to embedded_distribution_folder\Lib or to embedded_distribution_folder\
   3. files _tkinter.pyd tcl86t.dll tk86t.dll (which are under DLLs) either to embedded_distribution_folder\DLLs or to embedded_distribution_folder\

### 自分の環境と同じ`python`のバージョンを使っている場合?

発生条件は不明だが、`python -m pip install`をした時にグローバルにインストールされる場合がある。
その場合、`python.exe -m pip install`とすれば良い。